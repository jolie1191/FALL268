/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/10/2013
 *This is the main class.
 */
#include <cstdlib>
#include <iostream>
#include "Executive.h"

int main(int argc, char **argv)
{
    if (argc == 5)
    {
        // get numbers from the arguments
        int rows = atoi(argv[1]);
        int cols = atoi(argv[2]);
        int x = atoi(argv[3]);
        int y = atoi(argv[4]);

        // create an executive object
        Executive ex;

        // run it
        ex.run(rows, cols, x, y);
    }
    else
    {
        // if the length is not 5, print invalid.
        std::cout << "The number of arguments is invalid." << std::endl;
    }
    return 0;
}
