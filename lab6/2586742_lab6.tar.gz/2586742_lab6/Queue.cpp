/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the implement of Queue class.
 */


//Default constructor
template<class ItemType>
Queue<ItemType>::Queue()
{
    front = back = NULL;
}

//deconstructor
template<class ItemType>
Queue<ItemType>::~Queue()
{
    while (front != NULL)
    {
        Node<ItemType> *temp = front;
        front = front->getNext();
        delete temp;
    }
}

/**
 *check the queue is empty
 *@return true if is empty
 */
template<class ItemType>
bool Queue<ItemType>::isEmpty() const
{
    return front == NULL;
}

/**
 *add a new item to the queue
 *@param the item to add
 */
template<class ItemType>
void Queue<ItemType>::enqueue(const ItemType& item)
throw (PrecondViolatedExcep)
{
    Node<ItemType> *node = new Node<ItemType>();
    node->setItem(item);
    node->setNext(NULL);
    if (isEmpty())
    {
        front = node;
    }
    else
    {
        back->setNext(node);
    }
    back = node;
}

/**
 *delete the item from the queue
 */
template<class ItemType>
void Queue<ItemType>::dequeue() throw (PrecondViolatedExcep)
{
    if (isEmpty())
    {
        throw PrecondViolatedExcep("Queue is empty");
    }
    Node<ItemType> *temp = front;
    front = front->getNext();
    if (front == NULL) 
      back = NULL;
    delete temp;
}

/**
 *look the front item of queue
 */
template<class ItemType>
ItemType Queue<ItemType>::peekFront() const throw(PrecondViolatedExcep)
{
    if (isEmpty())
    {
        throw PrecondViolatedExcep("Queue is empty");
    }
    return front->getItem();
}
