#include "Executive.h"

int main(int argc, char** argv) 
{
	if (argc == 2) 
	{
	   Executive ex;
	   ex.start(argv[1]);
	}
	else
	{
	   cout << "No input file." << endl;
	}
	return 0;
}
