/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 12/07/2013
 *This is header file of GeneralTree class.
 */

#ifndef _GENERAL_TREE
#define _GENERAL_TREE

#include "BinaryNode.h"
#include <cstdlib>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

template<class T>
class GeneralTree
{
private:
        BinaryNode<T> *root; // root node
        void remove(BinaryNode<T>* node); // remove all the nodes in a subtree

public:
	GeneralTree(); // constructor
	~GeneralTree(); // destructor
        
        /**
         *Converts an integer to string
         *@param convert number to string
         */
	static string toString(int number); 
        /**
         *Converts the tree to a parenthesized expression
         */
	string toString() const; 
	string toString(BinaryNode<T> *node) const; 

	void printTree() const; // prints out the tree
	void printTree(BinaryNode<T> *node, int indents) const; // prints out the tree

        /**
         *Loads input file
         *@param load from filename
         */
	void loadFile(string filename); 

        /**
         *Adds numNewChild as numParent first child
         *@param numParent parent
         *@param numNewChild new child
         */
	void addFirstChild(int numParent, int numNewChild); // adds first child
        /**
         *Adds numNewChild as numParent last child
         *@param numParent parent
         *@param numNewChild new child
         */
	void addLastChild(int numParent, int numNewChild); // adds last child
        BinaryNode<T> *addFirstChild(BinaryNode<T> *node, int numNewChild); // adds first child
        BinaryNode<T> *addLastChild(BinaryNode<T> *node, int numNewChild); // adds last child

        /**
         *Removes a node
         *@param romove the node 
         */
	void remove(int num); 

        BinaryNode<T> *getNode(BinaryNode<T> *node, int num) const; // find a node
        BinaryNode<T> *getParentNode(BinaryNode<T> *node, int num) const; // find parent of a node

        /**
         *Displays the parent node
         *@param display the node
         */
	void showParent(int num) const; 
	void showChildren(int num) const; // displays the child nodes 
	void showSiblings(int num) const; // displays the sibling nodes 
};

#include "GeneralTree.cpp"

#endif
