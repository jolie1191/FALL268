/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the main class.
 */

#include <iostream>
#include "Executive.h"

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        // get filename from arguments
        string filename = argv[1];

        // create an executive object
        Executive ex;

        // run it
        ex.run(filename);
    }
    else
    {
        // if the length is not 2, print error.
        cout << "The number of arguments is invalid." << endl;
    }
    return 0;
}
