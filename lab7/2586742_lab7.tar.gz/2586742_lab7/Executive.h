/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/10/2013
 *This is the header file of Executive class.
 */

#ifndef EXECUTIVE_H_
#define EXECUTIVE_H_

#include <ctime>
#include <sys/time.h>
#include <cstring>
#include <iostream>
#include <cstdlib>

//Define a function pointer
typedef void (*SortFunction)(double a[], int n);

/**
 *The operations that calls the each sort template function
 *@param array of number
 *@param the size of array
 */
void bubble_sort(double theArray[], int size);
void insertion_sort(double theArray[], int size);
void merge_sort(double theArray[], int size);
void quick_sort(double theArray[], int size);
void selection_sort(double theArray[], int size);

class Executive
{
public:
    /**
     *Constructor with given parameters
     *@param size of array
     *@param the array order
     *@param sort type to sort array
     */
    Executive(int size, std::string order, std::string type);
    /**
     *Desctructor
     */
    ~Executive();
    /**
     *find the time when use a sort type
     */
    void sort();
    /**
     *Print the result
     */
    void display();

private:
    /**
     *Get the current time 
     *@return the time
     */
    unsigned long getTime();
    /**
     *Array of numbers
     */
    double *array;
    /**
     *Array size
     */
    int size;

    unsigned long time;
    //sort type to use
    std::string type;
    //the order of array
    std::string order;
  
    SortFunction function;
};

#endif
