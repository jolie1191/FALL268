/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is implement of Executive. 
 */
#include "Executive.h"
#include "Knight.h"

/**
 * Runs the search program
 * @param rows rows of the board
 * @param cols cols of the board
 * @param x row of the start point
 * @param y column of the start point
 */
void Executive::run(int rows, int cols, int x, int y)
{

    // create a knight with the given size
    Knight knight(rows, cols);

    // search path from (x, y)
    knight.search(x, y);
}
