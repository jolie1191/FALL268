/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 12/07/2013
 *This is implement of GeneralTree class.
 */




#include "BinaryNode.h"

// constructor
template<class T>
GeneralTree<T>::GeneralTree()
{
	root = NULL;
}

// destructor
template<class T>
GeneralTree<T>::~GeneralTree()
{
  remove(root);
}

// remove all the nodes
template<class T>
void GeneralTree<T>::remove(BinaryNode<T>* node) {
  if (node)
  {
    remove(node->getLeftChildPtr());
    remove(node->getRightChildPtr());
    delete node;
  }
}

/**
 *Converts an integer to string
 *@param convert number to string
 */
template<class T>
string GeneralTree<T>::toString(int number)
{
	string s = "";
	do 
	{
		s += (char) (number % 10 + '0');
		number /= 10;
	} 
	while (number > 0);
	for (unsigned i = 0; i < s.size() / 2; i++) 
	{
		swap(s[i], s[s.size() - i - 1]);
	}
	return s;
}

/** 
 *Converts the tree to a parenthesized expression
 */
template<class T>
string GeneralTree<T>::toString() const
{
	return toString(root);
}

// convert the tree to a parenthesized expression
template<class T>
string GeneralTree<T>::toString(BinaryNode<T> *node) const
{
	if (node == NULL)
	{
		return "";
	}
	else
	{
		string res = "(" + toString(node->getItem())
			+ toString(node->getLeftChildPtr()) + ")"
			+ toString(node->getRightChildPtr());
		return res;
	}
}

// prints out the tree
template<class T>
void GeneralTree<T>::printTree() const
{
	printTree(root, 0);
}

// prints out the tree
template<class T>
void GeneralTree<T>::printTree(BinaryNode<T> *node, int indents) const
{
	if (node == NULL)
	{
		return;
	}
	cout << setw(indents) << " " << node->getItem() << endl;
	printTree(node->getLeftChildPtr(), indents + 4);
	printTree(node->getRightChildPtr(), indents);
}

/**
 *Loads input file
 *@param load from filename
 */
template<class T>
void GeneralTree<T>::loadFile(string filename)
{
	ifstream file(filename.c_str());
	if (file)
	{
           BinaryNode<T> *nodes[100];
           int nNodes = 0;
           string line;
	   getline(file, line);
	   for (unsigned i = 0; i < line.size();) 
           {
	      if (line[i] == '(')
	      {
		   int n = 0;
		   i++;
		   while (line[i] >= '0' && line[i] <= '9') 
		   {
		     n = n * 10 + line[i] - '0';
		     i++;
		   }
                  BinaryNode<T>* node = NULL;
	           if (nNodes == 0)
		   {
		     node = root = new BinaryNode<T>(n);
		   }
	           else
		   {
                     BinaryNode<T>* parent = nodes[nNodes - 1];
		     node = addLastChild(parent, n);
		   }
		   nodes[nNodes++] = node;
	      }
	      else if(line[i] ==')')
	      {
		--nNodes;
		++i;
	       }
              else 
              {
              ++i;
              }
	     }
	  file.close();
	}
        else
	{
	  cout << "File not found\n";
	  exit(1);
	}
}

/**
 *Adds numNewChild as numParent first child
 *@param parent
 *@param numNewChild new child
 */
template<class T>
BinaryNode<T> *GeneralTree<T>::addFirstChild(BinaryNode<T> *parent, int numNewChild)
{ 
	if (parent->getLeftChildPtr() != NULL)
	{
		// parent has a child
                BinaryNode<T>* firstChild = parent->getLeftChildPtr();
		parent->setLeftChildPtr(new BinaryNode<T>(numNewChild));
		parent->getLeftChildPtr()->setRightChildPtr(firstChild);
		return parent->getLeftChildPtr();
	}
	else
	{
		// parent has no child
		parent->setLeftChildPtr(new BinaryNode<T>(numNewChild));
		return parent->getLeftChildPtr();
	}
}

/**
 *Adds numNewChild as numParent last child
 *@param parent
 *@param numNewChild new child
 */
template<class T>
BinaryNode<T> *GeneralTree<T>::addLastChild(BinaryNode<T> *parent, int numNewChild)
{
	if (parent->getLeftChildPtr() != NULL)
	{
		// parent has a child
                BinaryNode<T>* lastChild;
		// find the last child
		for (lastChild = parent->getLeftChildPtr(); lastChild->getRightChildPtr() != NULL;
			lastChild = lastChild->getRightChildPtr());
		// add sibling to the last child
		lastChild->setRightChildPtr(new BinaryNode<T>(numNewChild));
		return lastChild->getRightChildPtr();
	}
	else
	{
		// parent has no child
		parent->setLeftChildPtr(new BinaryNode<T>(numNewChild));
		return parent->getLeftChildPtr();
	}
}


 // find a node
template<class T>
 BinaryNode<T> * GeneralTree<T>::getNode(BinaryNode<T> *node, int num) const
{
  BinaryNode<T>* res;
	if (node == NULL)
	{
		return NULL;
	}
	else if (node->getItem() == num)
	{
		return node;
	}
	else if (NULL != (res = getNode(node->getLeftChildPtr(), num)))
	{
		return res;
	}
	else if (NULL != (res = getNode(node->getRightChildPtr(), num)))
	{
		return res;
	}
	else 
	{
		return NULL;
	}
}

// find parent of a node
template<class T>
BinaryNode<T> *GeneralTree<T>::getParentNode(BinaryNode<T> *node, int num) const
{
     BinaryNode<T>* res;
	if (node == NULL)
	{
		return NULL;
	}
	else if (node->getLeftChildPtr() != NULL)
	{
		
		for (BinaryNode<T> *child = node->getLeftChildPtr(); child != NULL; child = child->getRightChildPtr())
		{
		   if (child->getItem() == num)
		   {
			return node;
		   }
		   else if (NULL != (res = getParentNode(child->getLeftChildPtr(), num)))
		   {
			return res;
	           }
		   else if (NULL != (res = getParentNode(child->getRightChildPtr(), num)))
		   {
			return res;
		   }
		}
		return NULL;
	}
	else
	{
		return NULL;
	}
}

/**
 *Displays the parent node
 *@param display the node
 */ 
template<class T>
void GeneralTree<T>::showParent(int num) const 
{
  BinaryNode<T>* child = getNode(root, num);
  BinaryNode<T>* parent = getParentNode(root, num);
	if (child == NULL)
	{
		cout << num << " was not found in the tree" << endl;
	}
	else if (parent == NULL)
	{
		cout << num << " does not have a parent" << endl;
	}
	else
	{
		cout << num << "'s parent is " << parent->getItem() << endl;
	}
}

/**
 *Displays the child node
 *@param display the node
 */
template<class T>
void GeneralTree<T>::showChildren(int num) const
{
    BinaryNode<T>* parent = getNode(root, num);
	if (parent == NULL)
	{
		cout << num << " was not found in the tree" << endl;
	}
	else if (parent->getLeftChildPtr() == NULL)
	{
		cout << num << " does not have a child" << endl;
	}
	else
	{
		cout << "child nodes of " << num << ":";
		for (BinaryNode<T> *child = parent->getLeftChildPtr(); child != NULL; child = child->getRightChildPtr())
		{
			cout << " " << child->getItem();
		}
		cout << endl;
	}
}

/**
 *Displays the siblings node
 *@param display the node
 */ 
template<class T>
void GeneralTree<T>::showSiblings(int num) const 
{
   BinaryNode<T>* child = getNode(root, num);
   BinaryNode<T>* parent = getParentNode(root, num);
	if (child == NULL)
	{
	   cout << num << " was not found in the tree" << endl;
	}
	else if (parent == NULL)
	{
           cout << num << " does not have a sibling" << endl;
	}
	else
	{
	   cout << num << "'s sibling(s):";
	   bool first = true;
	   for (BinaryNode<T> *sibling = parent->getLeftChildPtr(); sibling != NULL; sibling = sibling->getRightChildPtr())
	   {
		if (sibling->getItem() == num && first)
		{
			first = false;
		}
		else
		{
			cout << " " << sibling->getItem();
		}
	    }
	   cout << endl;
	}
}

// adds first child
template<class T>
void GeneralTree<T>::addFirstChild(int numParent, int numNewChild) 
{
  BinaryNode<T>* parent = getNode(root, numParent);
	if (parent == NULL)
	{
	  cout << numParent << " was not found in the tree" << endl;
	}
	else
	{
	  addFirstChild(parent, numNewChild);
	}
} 

// adds last child
template<class T>
void GeneralTree<T>::addLastChild(int numParent, int numNewChild) 
{
  BinaryNode<T>* parent = getNode(root, numParent);
	if (parent == NULL)
	{
	  cout << numParent << " was not found in the tree" << endl;
	}
	else
	{
	  addLastChild(parent, numNewChild);
	}
} 

/**
 *Removes a node
 *@param romove the node 
 */
template<class T>
void GeneralTree<T>::remove(int num)
{
  BinaryNode<T>* node = getNode(root, num);
	if (node == NULL)
	{
	  cout << num << " was not found in the tree" << endl;
	}
	else if (node == root)
	{
	    if (node->getLeftChildPtr() == NULL)
	    {
		delete root;
		root = NULL;
	    }
	    else
	    {
               cout << "Deleting the root node is not allowable unless it has no children" << endl;
	    }
	}
	else
	{
          BinaryNode<T>* parent = getParentNode(root, num);
          BinaryNode<T> *sibling;
		if (parent->getLeftChildPtr() != node)
		{
		  for (sibling = parent->getLeftChildPtr(); sibling->getRightChildPtr() != node; sibling = sibling->getRightChildPtr());
		        if (node->getLeftChildPtr() != NULL)
			{ 
			    sibling->setRightChildPtr(node->getLeftChildPtr());
                            for (sibling = node->getLeftChildPtr(); sibling->getRightChildPtr() != NULL; sibling = sibling->getRightChildPtr()) {}
                            sibling->setRightChildPtr(node->getRightChildPtr());
			}
			else
			{
                          sibling->setRightChildPtr(node->getRightChildPtr());
			}
		}
		else if (node->getLeftChildPtr() != NULL)
		{
			parent->setLeftChildPtr(node->getLeftChildPtr());
                        for (sibling = node; sibling->getRightChildPtr() != NULL; sibling = sibling->getRightChildPtr()) {}
                        sibling->setRightChildPtr(node->getRightChildPtr());
		} 
		else
		{
			 parent->setLeftChildPtr(node->getRightChildPtr());
		}
		node->setRightChildPtr(NULL);
		node->setLeftChildPtr(NULL);
		delete node;
	}
}
