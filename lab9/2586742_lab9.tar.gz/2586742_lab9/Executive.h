/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 12/07/2013
 *This is header file of Executive class.
 */

#ifndef _EXECUTIVE_H
#define _EXECUTIVE_H

#include "GeneralTree.h"
#include <string>
using namespace std;

class Executive {
private:
        GeneralTree<int> tree; // general tree
        /**
         *Read an integer
         */
	static int readInt(); 
        /**
         *Read a string
         */
	static string readString(); 
        /**
         *Display the menu
         */
	void showMenu();  
public:
       /**
        *Start the program
        */
       void start(string file); 
};

#endif
