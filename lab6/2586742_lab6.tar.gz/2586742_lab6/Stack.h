/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the header file of Stack class.
 */

#ifndef STACK_H
#define STACK_H

#include "StackInterface.h"
#include "Node.h"

template<class ItemType>
class Stack : public StackInterface<ItemType>
{
private:
    Node<ItemType> *top; //Pionter to the first node
public:
    Stack(); //Default constructor
    ~Stack(); //Destructor

    //Stack operations
    bool isEmpty() const; //Check the stack is empty
    /**
     *push the item to stack
     *@param the item to be pushed
     */
    void push(const ItemType& item) throw (PrecondViolatedExcep);
    /**
     *pop the top item 
     */
    void pop() throw (PrecondViolatedExcep);
    /**
     *look the top item
     *@return top item
     */
    ItemType peek() const throw (PrecondViolatedExcep);
}; //end LinkedStack

#include "Stack.cpp"
#endif
