/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 10/10/2013
 *This is header file of Executive. 
 */
#ifndef EXECUTIVE_H
#define EXECUTIVE_H

class Executive
{
public:
    /**
     * Run the search program
     * @param rows rows of the board
     * @param cols cols of the board
     * @param x row of the start point
     * @param y column of the start point
     */
    void run(int rows, int cols, int x, int y);
};


#endif
