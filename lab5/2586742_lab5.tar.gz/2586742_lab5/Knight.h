/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/10/2013
 *This is the header file of Knight class.
 */


#ifndef KNIGHT_H
#define KNIGHT_H

#include <iostream>
#include <iomanip>

class Knight
{
private:
    // size of the board
    int rows, cols;
    // array of the board
    int **Board;

    /**
     * Uses depth-first-search to find the path
     * @param x row of the current position
     * @param y col of the current position
     * @param depth current depth of recursion
     * @param maxDepth maximum depth of recursion
     * @param found whether a path is found
     */
    void dfs(int x, int y, int depth, int maxDepth, bool& found);

    /**
     * Determines whether a position is valid
     * @param x row of the position
     * @param y column of the position
     */
    bool isValid(int x, int y);

public:
    /**
     * Constructor
     * @param rows rows of the board
     * @param cols columns of the board
     */
    Knight(int rows, int cols);

    /**
     * Destructor
     */
    ~Knight();

    /**
     * Searches path starting from (x, y)
     * @param x row of the start position
     * @param y col of the start position
     */
    void search(int x, int y);
};


#endif
