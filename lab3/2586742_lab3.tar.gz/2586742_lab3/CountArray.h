/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 09/27/2013
 *This is header file of CountArray. It inlcudes the its instances(array, arraySize, numItemsStored), constructors, deconstructor and functions(bump the count and get item). 
 */


#ifndef CountArray_H_
#define CountArray_H_
#include "Count.h"

template <typename T>
class CountArray
{
private:
    /**
     *array of Count
     */
    Count<T>* array;
    /**
     *array size of array
     */
    int arraySize;
    /**
     *Number of items stored
     */
    int numItemsStored;
public:
    /**
     *Default constructor.
     */
    CountArray();
    /**
     *Copy constructor 
     *@param copy array from countArr
     */
    CountArray(const CountArray<T>& countArr);
    /**
     *Destructor
     */
    ~CountArray();
    /**
     *Bump the count of t
     *@param t in the array, bump its count
     */
    void bumpCount(T t);
    /**
     *Get the number of item stored
     */
    int getNumItemsStored() const;
    /**
     *Get the item.
     */
    Count<T> getItem(int whichItem) const;
};

#include "CountArray.cpp"
#endif
