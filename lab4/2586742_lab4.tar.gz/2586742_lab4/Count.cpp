/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is Count class with template. It includes what the functions(count number, set and get item, count) do.
 */

template <typename T>
Count<T>::Count()
{
} //end defalt constructor

template<typename T>
Count<T>::Count(T anItem){
  item = anItem;
  count =1;
}

template<typename T>
Count<T>::Count(const T& anItem)
{
   item = anItem.item;
   count = anItem.count;
} //end constructor

/**
 *Get the item
 *@return the item
 */
template<typename T>
T Count<T>::getItem() const
{
   return item;
}

/**
 *Increase and count the number of occurrence of each item
 */
template<typename T>
void Count<T>::CountNum(){
      count++;
}

/**
 *Get and return the occurence of each item
 *@return count
 */
template<typename T>
int Count<T>::getCount(){
   return count;
}

/**
 *Set the item
 */
template<typename T>
void Count<T>::setItem(T item){
    this->item = item;
}

/**
 *Set the occurence
 */
template<typename T>
void Count<T>::setCount(int count) {
    this->count = count;
}
