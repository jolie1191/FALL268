/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 12/07/2013
 *This is implement of Executive class.
 */

#include "Executive.h"

// starts the program
void Executive::start(string file) 
{
	tree.loadFile(file);
	showMenu();
	while (true)
	{
		cout << endl;
		cout << "input: ";
		string s = readString();
		if (s == "print")
		{
		   tree.printTree();
		}
		else if (s == "parent")
		{
		   tree.showParent(readInt());
		}
		else if (s == "siblings")
		{
		   tree.showSiblings(readInt());
		}
		else if (s == "children")
		{
		   tree.showChildren(readInt());
		}
		else if (s == "export")
		{
		   ofstream out(readString().c_str());
		   out << tree.toString() << endl;
		   out.close();
		}
		else if (s == "remove")
		{
		   tree.remove(readInt());
		}
		else if (s == "addfirst")
		{
		   int numParent = readInt();
		   int numNewChild = readInt();
	           tree.addFirstChild(numParent, numNewChild);
		}
		else if (s == "addlast")
		{
		   int numParent = readInt();
		   int numNewChild = readInt();
		   tree.addLastChild(numParent, numNewChild);
		}
		else if (s == "quit")
		{
		   break;
		}
		else
		{
		   cout << "Unknown command" << endl;
		}
	}

}

// reads an integer
int Executive::readInt() {
	int n;
	cin >> n;
	return n;
}

// reads a string
string Executive::readString() {
	string s;
	cin >> s;
	return s;
}

// displays the menu
void Executive::showMenu()
{
	cout << "command list: " << endl;
	cout << "  print" << endl;
	cout << "  parent x" << endl;
	cout << "  children x" << endl;
	cout << "  siblings x" << endl;
	cout << "  export file" << endl;
	cout << "  addfirst x y" << endl;
	cout << "  addlast x y" << endl;
	cout << "  remove x" << endl;
	cout << "  quit" << endl;
}
