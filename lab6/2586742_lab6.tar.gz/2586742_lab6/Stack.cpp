/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the implement of Stack class.
 */

//Default constructor
template<class ItemType>
Stack<ItemType>::Stack() {
    top = NULL;
}

//Destructor
template<class ItemType>
Stack<ItemType>::~Stack() {
    //delete until stack is empty
    while (top != NULL) {
        Node<ItemType> *temp = top;
        top = top->getNext();
        delete temp;
    }
}

//Check the stack is empty
template<class ItemType>
bool Stack<ItemType>::isEmpty() const {
    return top == NULL;
}

/**
 *push the item to stack
 *@param the item to be pushed
 */
template<class ItemType>
void Stack<ItemType>::push(const ItemType& item) throw (PrecondViolatedExcep) {
    Node<ItemType> *newNode = new Node<ItemType>();
    newNode->setNext(top);
    newNode->setItem(item);
    top = newNode;
}

/**
 *pop the top item 
 */
template<class ItemType>
void Stack<ItemType>::pop() throw (PrecondViolatedExcep) {
    if (isEmpty()) {
        throw PrecondViolatedExcep("Stack is empty");
    }
    Node<ItemType> *temp = top;
    top = top->getNext();
    delete temp;
}

/**
 *look the top item
 *@return top item
 */
template<class ItemType>
ItemType Stack<ItemType>::peek() const throw (PrecondViolatedExcep) {
    if (isEmpty()) {
        throw PrecondViolatedExcep("Stack is empty");
    }
    //Stack is not empty; return top
    return top->getItem();
}
