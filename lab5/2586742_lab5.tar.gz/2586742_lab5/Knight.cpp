/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 10/10/2013
 *This is implement of Knight. 
 */

#include "Knight.h"

/**
 * Constructor
 * @param rows rows of the board
 * @param cols columns of the board
 */
Knight::Knight(int r, int c)
{
    rows = r;
    cols = c;
    Board = new int *[rows];
    for (int i = 0; i < rows; i++)
        Board[i] = new int [cols];
}

/**
 * Destructor
 */
Knight::~Knight()
{
    for (int i = 0; i < rows; i++)
        delete[] Board[i];
    delete[] Board;
}

/**
 * Determines whether a position is valid
 * @param x row of the position
 * @param y column of the position
 */
bool Knight::isValid(int x, int y)
{
    return x >= 0 && x < rows && y >= 0 && y < cols;
}

/**
 * Use depth-first-search to find the path
 * @param x row of the current position
 * @param y col of the current position
 * @param depth current depth of recursion
 * @param maxDepth maximum depth of recursion
 * @param found whether a path is found
 */
void Knight::dfs(int x, int y, int depth, int maxDepth, bool& found)
{
    // found the path
    if (depth == maxDepth)
    {
        found = true;
        return;
    }

    // offsets array
    static int offsetX[] = {1, 1, -1, -1, 2, 2, -2, -2};
    static int offsetY[] = {2, -2, 2, -2, 1, -1, 1, -1};

    for (int i = 0; i < 8; i++)
    {
        int x2 = x + offsetX[i];
        int y2 = y + offsetY[i];

        // if (x2,y2) is valid and not visited
        if (isValid(x2, y2) && Board[x2][y2] == -1)
        {
            // move to (x2,y2) at this step
            Board[x2][y2] = depth;
            // search the next step
            dfs(x2, y2, depth + 1, maxDepth, found);
            if (found) return;
            Board[x2][y2] = -1;
        }
    }
}


/**
 * Searches path starting from (x, y)
 * @param x row of the start position
 * @param y col of the start position
 */
void Knight::search(int x, int y)
{
    // initialize the board
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            if (i == x && j == y)
                Board[i][j] = 0;
            else
                Board[i][j] = -1;

    // search path
    bool found = false;
    dfs(x, y, 1, rows * cols, found);

    // print the result
    if(found == true)
      std::cout<< "Success!"<< std::endl;
    else 
      std::cout<< "Failed!" << std::endl;
    
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++) {
            std::cout << "[";
            if (Board[i][j] == -1)
                std::cout << "  ";
            else
                std::cout << std::setw(2) << Board[i][j];
            std::cout << "]";
        }
        std::cout << std::endl;
    }
}
