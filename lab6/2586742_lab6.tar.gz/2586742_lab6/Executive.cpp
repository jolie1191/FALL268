/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the implement of Executive class.
 */


#include <fstream>
#include <iostream>
#include "Executive.h"
#include <cstdlib>

/**
 * Runs the simulation
 *
 * @param filename name of the input file
 */
void Executive::run(string filename)
{

    ifstream in(filename.c_str());

    if (!in)
    {
        cout << filename << " does not exists." << endl;
        exit(0);
    }

    string s;

    while (in >> s)
    {
        if (s == "done")
        {
            serviceFinish();
        }
        else if (s == "show")
        {
            show();
        }
        else if (isVIPCustomer(s))
        {
            VIPArrive(s);
        }
        else
        {
            customerArrive(s);
        }
    }
    in.close();
}

/**
 * Shows the customer being served and the next customer
 */
void Executive::show()
{
    // no one is being served
    if (getCustomerBeingServed() == "")
    {
        cout << "*** No one is currently being served ***" << endl;
        return;
    }

    // VIP is being served
    if (isVIPCustomer(getCustomerBeingServed()))
    {
        cout << "*** " << getCustomerBeingServed() << " is currently being serverd; ";
        if (customerQueue.isEmpty())
        {
            cout << "No one is waiting in the queue";
        }
        else
        {
            cout << customerQueue.peekFront() << " is waiting in the queue";
        }

    }
    else
    {
        // customer is being served
        cout << "*** " << getCustomerBeingServed() << " is currently being serverd";
    }
    cout << " ***" << endl;
}

/**
 * Finishes serving a customer
 */
void Executive::serviceFinish()
{
    // no one is being served
    if (getCustomerBeingServed() == "")
    {
        cout << ".. No customer is being serverd .." << endl;
        return;
    }

    // show the customer being served
    cout << ".. " << getCustomerBeingServed() << " is done; ";

    if (isVIPCustomer(getCustomerBeingServed()))
    {
        // vip is being served
        if (VIPStack.isEmpty())
        {
            // no vip in the stack
            VIPBeingServed = "";
            if (getCustomerBeingServed() == "")
            {
                cout << "no one is waiting, Lydia rests .." << endl;
            }
            else
            {
                cout << getCustomerBeingServed() << " is starting .." << endl;
            }

        }
        else
        {
            // resume vip in the stack
            VIPBeingServed = VIPStack.peek();
            VIPStack.pop();
            cout << getCustomerBeingServed() << " is resuming .." << endl;
        }

    }
    else
    {
        // dequeue the first customer in the queue
        customerQueue.dequeue();
        if (getCustomerBeingServed() == "") {
            cout << "no one is waiting, Lydia rests .." << endl;
        } else {
            cout << getCustomerBeingServed() << " is starting .." << endl;
        }
    }
}


/**
 * A vip customer arrives
 * @param name customer name
 */
void Executive::VIPArrive(string name)
{
    cout << "## " << name << " arrives for service; ";
    if (VIPBeingServed == "")
    {
        VIPBeingServed = name;
        cout << name << " immediately starts getting served";

    }
    else if (compareVIP(VIPBeingServed, name) >= 0)
    {
        cout << name << " sees " << VIPBeingServed
                << " being served and immediately leaves";

    }
    else
    {
        cout << VIPBeingServed << " is suspended; " << name
                << " immediately starts getting served";
        VIPStack.push(VIPBeingServed);
        VIPBeingServed = name;
    }
    cout << " ##" << endl;
}


/**
 * A customer arrives
 * @param name customer name
 */
void Executive::customerArrive(string name)
{
    customerQueue.enqueue(name);
    cout << "## " << name << " arrives for service; ";
    if (getCustomerBeingServed() == name)
    {
        cout << name << " immediately starts being served";
    }
    else
    {
        cout << name << " is waiting in the queue";
    }
    cout << " ##" << endl;
}

/**
 * Compares two vips
 * @param name customer name
 */
int Executive::compareVIP(string name1, string name2)
{
    return atoi(name1.substr(3).c_str()) - atoi(name2.substr(3).c_str());
}

/**
 * @param name customer name
 * @return true if the name is VIP and false otherwise
 */
bool Executive::isVIPCustomer(string name)
{
    return name.length() >= 3 && name.substr(0, 3) == "VIP";
}

/**
 * @return the customer being served
 */
string Executive::getCustomerBeingServed()
{
    if (VIPBeingServed != "")
        return VIPBeingServed;
    try
    {

        return customerQueue.peekFront();
    }
    catch(PrecondViolatedExcep& e)
    {
        return NULL;
    }
}
