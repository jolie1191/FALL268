/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is the Executive class. It inludes functions(print, read file), constructor(load files).
 */


#include "Executive.h"
#include <iostream>
#include <cstdlib>

/**
 *print the list
 *@param list is printed 
 */
template <typename ItemType>
void Executive::print(CountList<ItemType> list) {
    for (int i = 0; i < list.getNumItemsStored(); i++) {
        Count<ItemType> item = list.getItem(i);
        std::cout << "(" << item.getItem() << ", " << item.getCount() << ")" << "\n";
    }
}

/**
 *read content of stream
 *@param input stream
 *@list count list 
 */
template <typename ItemType>
void Executive::read(std::istream& is, CountList<ItemType>& list) {
    ItemType t;
    while (is >> t)
        list.bumpCount(t);//bump the count.
}

/**
 *constructor with given input stream of char, int, string files
 */
Executive::Executive(std::istream& charFile, std::istream& intFile, std::istream& stringFile) {
    read<char>(charFile, charList); //read the content of charFile and bump
    // count.
    read<int>(intFile, intList); //read the content of intFile and bump count
    read<std::string>(stringFile, strList); //read content and bump count
}

void Executive::print() const {
    std::cout << "char input File:" << std::endl;
    print(charList);//print the char item and its count
    std::cout << "int input File:" << std::endl;
    print(intList); //print the int item and its count
    std::cout << "std::string input File:" << std::endl;
    print(strList); //print the string item and its count
}
