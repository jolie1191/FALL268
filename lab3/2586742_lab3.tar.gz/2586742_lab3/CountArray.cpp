
 /**
  *Default constructor.
  *Initialize arraySize, numItemsStored
  *Create an array
  */
template<typename T>
CountArray<T>::CountArray() {
    arraySize = 10;
    numItemsStored = 0;
    array = new Count<T>[arraySize];
}

/**
 *Copy constructor 
 *@param copy array from countArr
 */
template<typename T>
CountArray<T>::CountArray(const CountArray<T>& countArr) {
    arraySize = countArr.arraySize;
    array = new Count<T>[arraySize];
    numItemsStored = countArr.numItemsStored;
    for (int i = 0; i < numItemsStored; i++) {
        array[i] = countArr.getItem(i);
    }
}

/**
 *Destructor
 */
template<typename T>
CountArray<T>::~CountArray() {
    delete[] array;
}

/**
 *Bump the count of t
 *@param t in the array, bump its count
 */
template<typename T>
void CountArray<T>::bumpCount(T t) {
    for (int i = 0; i < numItemsStored; i++) {
        if (array[i].getItem() == t){ //if "t" in the array
            array[i].CountNum(); //bump its count
            return;
    }
    }
    if (numItemsStored == arraySize) { 
        arraySize =arraySize * 2; //replace array twice the current size
        Count<T> *b = new Count<T>[arraySize];
        for (int i = 0; i < numItemsStored; i++) {
            b[i] = array[i]; //copy the current contents over
        }
        delete[] array; //delete the old array
        array = b; //make new array be the current array
    }
    /**
     *Add the entry at the end
     */
    array[numItemsStored].setItem(t);
    array[numItemsStored++].setCount(1);
}

/**
 *Get the number of item stored
 */
template<typename T>
int CountArray<T>::getNumItemsStored() const {
    return numItemsStored;
}

/**
 *Get the item.
 */
template<typename T>
Count<T> CountArray<T>::getItem(int whichItem) const {
    return array[whichItem];
}
