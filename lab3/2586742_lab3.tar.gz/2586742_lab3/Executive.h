/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 09/27/2013
 *This is the header file of Executive class. It includes fucntions(print, read), constructor and its instances(charArray, intArray, strArray).
 */


#ifndef Executive_H_
#define Executive_H_
#include "CountArray.h"
#include <string>
#include <iostream>
#include <fstream>


class Executive
{
private:
    /**
     *array of char 
     */
    CountArray<char> charArray;
    /**
     *array of int
     */
    CountArray<int> intArray;
    /**
     *array of string
     */
    CountArray<std::string> strArray;

    /**
     *print the array
     *@param arr is printed 
     */
    template <typename T>
    static void print(CountArray<T> arr);
    
    /**
     *read content of stream
     *@param input stream
     *@arr count array 
     */
    template <typename T>
    static void read(std::istream& is, CountArray<T>& arr);

public:
    /**
     *constructor with given input stream of char, int, string files
     */
    Executive(std::istream& charFile, std::istream& intFile,
              std::istream& stringFile);
    /**
     *Print
     */
    void print() const;
};

#endif
