/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is implement of CountList. 
 */



/**
 * Default constructor.
 */
template<typename ItemType>
CountList<ItemType>::CountList() {
    // create an empty list
	head = NULL;
	numItemsStored = 0;
}

/**
 * Destructor
 */
template<typename ItemType>
CountList<ItemType>::~CountList() {
	Node<Count<ItemType> >* temp;
    // use while to traverse the list and delete all the nodes
    while (head != NULL) {
        temp = head;
        head = head->getNext();
        delete temp;
    }
}

/**
 * Copy constructor
 * @param copy List from countList
 */
template<typename ItemType>
CountList<ItemType>::CountList(const CountList<ItemType>& countList){
	head = NULL;
	numItemsStored = 0;
    // loop for each cur in the list
    Node<Count<ItemType> >*cur = countList.head;
    while (cur != NULL) {
        // use bumpCount() to insert data
        for (int i = 0; i < cur->getItem().getCount(); i++) {
            bumpCount(cur->getItem().getItem());
        }
        cur = cur->getNext();
    }
}

/**
 *Bump the count of t
 *@param t in the list, bump its count
 */
template<typename ItemType>
void CountList<ItemType>::bumpCount(ItemType t) {

    // check if empty or the item is smaller than the head item
    if (head == NULL || t < head->getItem().getItem()) {
        // create a new node and set it to be the head
        Count<ItemType> item;
        item.setItem(t);
        item.setCount(1);
        Node<Count<ItemType> > *node = new Node<Count<ItemType> >(item);
        node->setNext(head);
        head = node;
        numItemsStored++;

    } else {
        // check if the item exists in the list
        Node<Count<ItemType> > *cur = head;
        while (cur != NULL) {
            if (cur->getItem().getItem() == t) {
                // increase the count
                Count<ItemType> item = cur->getItem();
                item.CountNum();
                cur->setItem(item);
                return;
            }
            cur = cur->getNext();
        }

        // if not exists, create a new node
        Count<ItemType> item;
        item.setItem(t);
        item.setCount(1);
        Node<Count<ItemType> > *node = new Node<Count<ItemType> >(item);

        // insert it before the first item larger than it
        cur = head;
        while (cur->getNext() != NULL) {
            if (cur->getNext()->getItem().getItem() > t) {
                node->setNext(cur->getNext());
                cur->setNext(node);
                numItemsStored++;
                return;
            }
            cur = cur->getNext();
        }

        // insert after the last node
        cur->setNext(node);
        numItemsStored++;
    }
}

/**
 * Get the number of item stored
 */
template<typename ItemType>
int CountList<ItemType>::getNumItemsStored() const {
    return numItemsStored;
}

/**
 * Get the item.
 */
template<typename ItemType>
Count<ItemType> CountList<ItemType>::getItem(int whichItem) const {
    // go to the whichItem-th cur
    Node<Count<ItemType> >*cur = head;
    for (int i = 0; i < whichItem; i++) {
        cur = cur->getNext();
    }
    // return the current item
    return cur->getItem();
}
