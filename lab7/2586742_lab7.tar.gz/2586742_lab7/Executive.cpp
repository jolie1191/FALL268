/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/10/2013
 *This is the implement of Executive class.
 */

#include "Executive.h"
#include "Sorts.h"


/**
 *The operations that calls the each sort template function
 *@param array of number
 *@param the size of array
 */
void bubble_sort(double theArray[], int size)
{
    bubbleSort<double>(theArray, size);
}

void insertion_sort(double theArray[], int size)
{
    insertionSort<double>(theArray, size);
}

void merge_sort(double theArray[], int size)
{
    mergesort<double>(theArray, size);
}

void quick_sort(double theArray[], int size)
{
    quicksort<double>(theArray, size);
}

void selection_sort(double theArray[], int size)
{
    selectionSort<double>(theArray, size);
}

/**
 *Constructor with given parameters
 *@param size of array
 *@param the array order
 *@param sort type to sort array
 */
Executive::Executive(int Size, std::string Order, std::string Type)
{
    size = Size;
    order = Order;
    type = Type;
    array = new double [size];

    // Choose the sorting function
    if (type == "selection")
    {
        function = &selection_sort;
    }
    else if (type == "insertion")
    {
        function = &insertion_sort;
    }
    else if (type == "bubble")
    {
        function = &bubble_sort;
    }
    else if (type == "merge")
    {
        function = &merge_sort;
    }
    else if (type == "quick")
    {
        function = &quick_sort;
    }
    else
    {
        std::cout << "The sort function is invalid." << std::endl;
        exit(0);
    }


    // Generate array elements
    if (order == "random")
    {   //Get the random array
        for (int i = 0; i < size; i++)
            array[i] = drand48();
    }//Get the ascending array
    else if (order == "ascending")
    {
        for (int i = 0; i < size; i++)
            array[i] = 0.001 * static_cast<double>(i);
    }//Get the descending array
    else if (order == "descending")
    {
        for (int i = 0; i < size; i++)
            array[i] = 0.001 * static_cast<double>(size - i - 1);
    }
    else
    {
        std::cout << "The sort order is invalid." << std::endl;
        exit(0);
    }
}

/**
 *Desctructor
 */
Executive::~Executive()
{
    delete[] array;
}

/**
 *Get the current time 
 *@return the time
 */
unsigned long Executive::getTime()
{
    timeval tv;
    gettimeofday(&tv, NULL);
    return (unsigned long) (tv.tv_sec * 1000000ul + tv.tv_usec);
}

/**
 *find the time when use a sort type
 */
void Executive::sort()
{
    unsigned long start = getTime();
    function(array, size);
//    for (int i = 0; i < size; i++)
//        std::cout << array[i] << ",";
//    std::cout << std::endl;
    unsigned long stop= getTime();
    time = stop - start;
}

/**
 *Print the result
 */
void Executive::display()
{
    std::cout << "Array size: " << size << std::endl;
    std::cout << "Sort type: " << type << std::endl;
    std::cout << "Array order: " << order << std::endl;
    std::cout << "Used time: " << time << std::endl;
}

