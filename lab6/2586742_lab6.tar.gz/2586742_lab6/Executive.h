/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the header file of Executive class.
 */


#ifndef EXECUTIVE_H
#define EXECUTIVE_H

#include "Stack.h"
#include "Queue.h"

class Executive
{
public:
    /**
     * Runs the simulation
     *
     * @param filename name of the input file
     */
    void run(string filename);

private:

    /**
     * Shows the customer being served and the next customer
     */
    void show();

    /**
     * Finishes serving a customer
     */
    void serviceFinish();

    /**
     * A vip customer arrives
     * @param name customer name
     */
    void VIPArrive(string name);

    /**
     * A customer arrives
     * @param name customer name
     */
    void customerArrive(string name);

    /**
     * Compares two vips
     * @param name customer name
     */
    int compareVIP(string name1, string name2);

    /**
     * @param name customer name
     * @return true if the name is VIP and false otherwise
     */
    bool isVIPCustomer(string name);

    /**
     * @return the customer being served
     */
    string getCustomerBeingServed();

    // Customer queue
    Queue<string> customerQueue;
    // VIP customer stack
    Stack<string> VIPStack;
    // VIP being served
    string VIPBeingServed;
};

#endif
