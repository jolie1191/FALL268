/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is the header file of Count class.
 */
#ifndef Count_H_
#define Count_H_

template <typename T>
class Count
{
private:
    /**
     *The item
     */
    T item;
    /**
     *Count item
     */
    int count;
public:
    /**
     *Default constructor
     */
    Count();
    /**
     *Copy constructor
     *@param copy object from anItem
     */
    Count(const T& anItem);
    /**
     *Get the item
     *@return the item
     */
    Count(T anItem);
    T getItem() const;
    /**
     *Increase and count the number of occurrence of each item
     */
    void CountNum();
    /**
     *Get and return the occurence of each item
     */
    int getCount();

    void setItem(T item);
    void setCount(int count);
    
};

#include "Count.cpp"
#endif
