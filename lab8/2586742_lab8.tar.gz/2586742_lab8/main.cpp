#include "Executive.h"

int main(int argc, char **argv)
{

    if (argc == 5 || argc == 4)
    {
        // get numbers from the arguments
        int size = atoi(argv[1]);
        std::string order = argv[2];
        std::string type = argv[3];
        int threshold = argc == 4 ? 0 : atoi(argv[4]);

        // make sure same numbers will be generated when the size is same and
        // order/type are different.
        srand48(size);

        // create an executive object
        Executive ex(size, order, type, threshold);

        // run sort algorithm
        ex.sort();

        // display result
        ex.display();
    }
    else
    {
        // if the length is not 4 or 5, print invalid.
        std::cout << "The number of arguments is invalid." << std::endl;
    }
    return 0;
}
