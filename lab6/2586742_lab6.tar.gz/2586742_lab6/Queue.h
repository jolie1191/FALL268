/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/02/2013
 *This is the header file of Queue class.
 */



#ifndef QUEUE_H
#define QUEUE_H

#include "QueueInterface.h"
#include "Node.h"

template<class ItemType>
class Queue : public QueueInterface<ItemType>
{
private:
    //front pionter for front of queue, and back ptr for the back of queue
    Node<ItemType> *front, *back;
public:
    //Default constructor
    Queue();
    //deconstructor
    ~Queue();
    /**
     *check the queue is empty
     *@return true if is empty
     */
    bool isEmpty() const;
    /**
     *add a new item to the queue
     *@param the item to add
     */
    void enqueue(const ItemType& item) throw (PrecondViolatedExcep);
    /**
     *delete the item from the queue
     */
    void dequeue() throw (PrecondViolatedExcep);
    /**
     *look the front item of queue
     */
    ItemType peekFront() const throw(PrecondViolatedExcep);
};

#include "Queue.cpp"

#endif
