/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 11/17/2013
 *This is the header file of Executive class.
 */
#ifndef EXECUTIVE_H_
#define EXECUTIVE_H_

#include <ctime>
#include <sys/time.h>
#include <cstring>
#include <iostream>
#include <cstdlib>

//Define a function pointer
typedef void (*SortFunction)(double a[], int n);


class Executive {
public:
    /**
     *The operations that calls each sort template function
     *@param array of number
     *@param the size of array
     */
    static void bubble_sort(double theArray[], int size);
    static void insertion_sort(double theArray[], int size);
    static void merge_sort(double theArray[], int size);
    static void quick_sort(double theArray[], int size);
    static void selection_sort(double theArray[], int size);
    static void Merge_bubble_sort(double theArray[], int size);
    static void Merge_insertion_sort(double theArray[], int size);
    static void Quick_bubble_sort(double theArray[], int size);
    static void Quick_insertion_sort(double theArray[], int size);

    /**
     *Constructor with given parameters
     *@param size of array
     *@param the array order
     *@param sort type to sort array
     */
    Executive(int size, std::string order, std::string type, int threshold);

    /**
     *Desctructor
     */
    ~Executive();

    /**
     *find the time when use a sort type
     */
    void sort();

    /**
     *Print the result
     */
    void display();

private:
    /**
     *Get the current time
     *@return the time
     */
    unsigned long getTime();

    /**
     *Array of numbers
     */
    double *array;
    /**
     *Array size
     */
    int size;

    unsigned long time;
    //sort type to use
    std::string type;
    //the order of array
    std::string order;

    static int threshold;

    SortFunction function;
};

#endif
