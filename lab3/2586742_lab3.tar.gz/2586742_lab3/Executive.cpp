/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 09/27/2013
 *This is the Executive class. It inludes functions(print, read file), constructor(load files).
 */


#include "Executive.h"
#include <iostream>
#include <cstdlib>

/**
 *print the array
 *@param arr is printed 
 */
template <typename T>
void Executive::print(CountArray<T> arr) {
    for (int i = 0; i < arr.getNumItemsStored(); i++) {
        Count<T> item = arr.getItem(i);
        std::cout << "(" << item.getItem() << ", " << item.getCount() << ")" << "\n";
    }
}

/**
 *read content of stream
 *@param input stream
 *@arr count array 
 */
template <typename T>
void Executive::read(std::istream& is, CountArray<T>& arr) {
    T t;
    while (is >> t)
        arr.bumpCount(t);//bump the count.
}

/**
 *constructor with given input stream of char, int, string files
 */
Executive::Executive(std::istream& charFile, std::istream& intFile, std::istream& stringFile) {
    read<char>(charFile, charArray); //read the content of charFile and bump count.
    read<int>(intFile, intArray); //read the content of intFile and bump count
    read<std::string>(stringFile, strArray); //read content and bump count
}

void Executive::print() const {
    std::cout << "char input File:" << std::endl;
    print(charArray);//print the char item and its count
    std::cout << "int input File:" << std::endl;
    print(intArray); //print the int item and its count
    std::cout << "std::string input File:" << std::endl;
    print(strArray); //print the string item and its count
}
