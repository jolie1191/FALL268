/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is the header file of Executive. 
 */


#ifndef Executive_H_
#define Executive_H_
#include "CountList.h"
#include <string>
#include <iostream>
#include <fstream>


class Executive
{
private:
    /**
     *list of char
     */
    CountList<char> charList;
    /**
     * list of int
     */
    CountList<int> intList;
    /**
     * list of string
     */
    CountList<std::string> strList;

    /**
     *print the list
     *@param list is printed 
     */
    template <typename ItemType>
    static void print(CountList<ItemType> list);
    
    /**
     *read content of stream
     *@param input stream
     *@arr count list
     */
    template <typename ItemType>
    static void read(std::istream& is, CountList<ItemType>& list);

public:
    /**
     *constructor with given input stream of char, int, string files
     */
    Executive(std::istream& charFile, std::istream& intFile,
              std::istream& stringFile);
    /**
     *Print
     */
    void print() const;
};

#endif
