/*
 *Author: Jiahui Wang
 *KUID: 2586742
 *Date: 09/27/2013
 *This is the main class.
 */
#include <iostream>
#include <fstream>
#include "Executive.h"

int main(int argc, char *argv[]) {
    if (argc == 4) { // if the length of argv is 4
        std::ifstream input1(argv[1]); //read the file to input1
        std::ifstream input2(argv[2]); //read the file to input2
        std::ifstream input3(argv[3]); //read the file to input3
      /**
       *Decide whether the files can be read
       *if not, then print file does not exist
       */
       if (!input1) {
          std::cout << argv[1] << " does not exist." << std::endl;
          return 0;
      }
       if (!input2) {
          std::cout << argv[2] << " does not exist." << std::endl;
          return 0;
      }
       if (!input3) {
          std::cout << argv[3] << " does not exist" << std::endl;
          return 0;
      }
        /**
         *Create the object with given input stream
         */
        Executive e1(input1, input2, input3); 
        input1.close();
        input2.close();
        input3.close();
        e1.print(); //print results.
    }
    else { // if the length is not 4, print invalid.
        std::cout << "The number of arguments is invalid." << std::endl;
    }
    return 0;
}
