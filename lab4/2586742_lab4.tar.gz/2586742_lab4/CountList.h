/*
 *Author: Jiahui wang
 *KUID: 2586742
 *Date: 10/05/2013
 *This is header file of CountList. It inlcudes the its instances(head pointer, numItemsStored), constructors, deconstructor and functions(bump the count and get item). 
 */
#ifndef CountList_H_
#define CountList_H_

#include "Count.h"
#include "Node.h"

template<typename ItemType>
class CountList
{
private:
    /**
     *Head pointer
     */
    Node<Count<ItemType> >* head;
    /**
     *Number of items stored
     */
    int numItemsStored;

public:
    /**
     *Default constructor.
     */
    CountList();
    /**
     *Destructor
     */
    ~CountList();
    /**
     *Copy constructor
     *@param copy List from countList
     */
    CountList(const CountList<ItemType>& countList);
    /**
     *Bump the count of t
     *@param t in the array, bump its count
     */
    void bumpCount(ItemType t);
    /**
     *Get the number of item stored
     */
    int getNumItemsStored() const;
    /**
     *Get the item.
     */
    Count<ItemType> getItem(int whichItem) const;

};

#include "CountList.cpp"
#endif
